import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function App1() {
  return (
    <View style={styles.container}>
      <Text style={styles.hello}>Olá, mundp! </Text>
      <Text style={styles.subtitle}>Meu primeiro app React Native!</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  hello: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#4CAF50',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#333',
    textAlign: 'center',
    marginTop: 10,
  },
});
