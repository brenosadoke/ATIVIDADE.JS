import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

export default function App2() {
  const [tamanho, setTamanho] = useState('');
  const [senha, setSenha] = useState('');

  const gerarSenha = () => {
    const n = parseInt(tamanho);
    if (isNaN(n) || n <= 0) {
      Alert.alert('Erro', 'Digite um número válido maior que zero!');
      return;
    }

    const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let novaSenha = '';
    for (let i = 0; i < n; i++) {
      const indice = Math.floor(Math.random() * caracteres.length);
      novaSenha += caracteres[indice];
    }
    setSenha(novaSenha);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senhas 🔒</Text>
      <TextInput
        style={styles.input}
        placeholder="Tamanho da senha"
        keyboardType="numeric"
        value={tamanho}
        onChangeText={setTamanho}
      />
      <Button title="Gerar Senha" onPress={gerarSenha} />
      {senha !== '' && (
        <Text style={styles.senha}>Senha gerada: {senha}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#4CAF50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#999',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  senha: {
    marginTop: 20,
    fontSize: 18,
    textAlign: 'center',
    color: '#333',
  },
});
