import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

export default function App4() {
  const [celsius, setCelsius] = useState('');
  const [fahrenheit, setFahrenheit] = useState('');

  const converterCParaF = () => {
    const c = parseFloat(celsius);
    if (isNaN(c)) {
      Alert.alert('Erro', 'Digite um número válido!');
      return;
    }
    const f = (c * 9) / 5 + 32;
    setFahrenheit(f.toFixed(2));
  };

  const converterFParaC = () => {
    const f = parseFloat(fahrenheit);
    if (isNaN(f)) {
      Alert.alert('Erro', 'Digite um número válido!');
      return;
    }
    const c = ((f - 32) * 5) / 9;
    setCelsius(c.toFixed(2));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Conversor de Temperatura </Text>

      <TextInput
        style={styles.input}
        placeholder="Celsius"
        keyboardType="numeric"
        value={celsius}
        onChangeText={setCelsius}
      />
      <Button title="Converter para Fahrenheit" onPress={converterCParaF} />

      <TextInput
        style={styles.input}
        placeholder="Fahrenheit"
        keyboardType="numeric"
        value={fahrenheit}
        onChangeText={setFahrenheit}
      />
      <Button title="Converter para Celsius" onPress={converterFParaC} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#4CAF50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#999',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
});
