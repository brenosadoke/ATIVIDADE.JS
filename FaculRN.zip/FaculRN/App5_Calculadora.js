import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

export default function App5() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [resultado, setResultado] = useState('');

  const calcular = (operacao) => {
    const n1 = parseFloat(num1);
    const n2 = parseFloat(num2);

    if (isNaN(n1) || isNaN(n2)) {
      Alert.alert('Erro', 'Digite números válidos!');
      return;
    }

    let res = 0;
    switch (operacao) {
      case 'soma':
        res = n1 + n2;
        break;
      case 'subtracao':
        res = n1 - n2;
        break;
      case 'multiplicacao':
        res = n1 * n2;
        break;
      case 'divisao':
        if (n2 === 0) {
          Alert.alert('Erro', 'Divisão por zero não é permitida!');
          return;
        }
        res = n1 / n2;
        break;
      default:
        return;
    }
    setResultado(res);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora Simpl</Text>

      <TextInput
        style={styles.input}
        placeholder="Número 1"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
        style={styles.input}
        placeholder="Número 2"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />

      <View style={styles.botoes}>
        <Button title="+" onPress={() => calcular('soma')} />
        <Button title="–" onPress={() => calcular('subtracao')} />
        <Button title="×" onPress={() => calcular('multiplicacao')} />
        <Button title="÷" onPress={() => calcular('divisao')} />
      </View>

      {resultado !== '' && (
        <Text style={styles.resultado}>Resultado: {resultado}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#4CAF50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#999',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  botoes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  resultado: {
    marginTop: 20,
    fontSize: 18,
    textAlign: 'center',
    color: '#333',
  },
});
