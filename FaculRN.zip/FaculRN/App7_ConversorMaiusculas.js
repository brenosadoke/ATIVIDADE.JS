import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function App7() {
  const [texto, setTexto] = useState('');
  const [resultado, setResultado] = useState('');

  const converterMaiusculas = () => {
    setResultado(texto.toUpperCase());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Conversor para Maiúsculas 🔠</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite um texto"
        value={texto}
        onChangeText={setTexto}
      />

      <Button title="Converter" onPress={converterMaiusculas} />

      {resultado !== '' && (
        <Text style={styles.resultado}>Resultado: {resultado}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#4CAF50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#999',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  resultado: {
    marginTop: 20,
    fontSize: 18,
    textAlign: 'center',
    color: '#333',
  },
});
