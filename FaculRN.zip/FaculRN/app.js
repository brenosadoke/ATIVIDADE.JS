import React from 'react';
import App1 from './App1_HelloWorld';
// import App2 from './App2_GeradorSenha';
// import App3 from './App3_Contador';
// import App4 from './App4_ConversorTemperatura';
// import App5 from './App5_Calculadora';
// import App6 from './App6_Login';
// import App7 from './App7_ConversorMaiusculas';

export default function App() {
  return <App1 />; // aqui você troca pelo app que quer testar
}
