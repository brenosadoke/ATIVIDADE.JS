// att1.js
let A = 5;
let B = 3;
let C = 10;

let soma = A + B;
console.log("Soma:", soma);

if (soma < C) {
  console.log("A soma é menor que C");
} else {
  console.log("A soma não é menor que C");
}
