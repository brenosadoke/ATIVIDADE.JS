// att2.js
let num = -4;

console.log(num % 2 === 0 ? "Par" : "Ímpar");
console.log(num >= 0 ? "Positivo" : "Negativo");
