// Em att3.js
{
  let A = 5;
  let B = 5;
  let C;

  if (A === B) {
    C = A + B;
  } else {
    C = A * B;
  }

  console.log("Resultado da att3:", C);
}
