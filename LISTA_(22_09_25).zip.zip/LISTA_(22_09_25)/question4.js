// Em att4.js
{
  let numero = 10;
  console.log("Antecessor:", numero - 1);
  console.log("Sucessor:", numero + 1);
}
