// att5.js
let salarioUsuario = 2500;
const salarioMinimo = 1525;

let qtd = salarioUsuario / salarioMinimo;
console.log("Você ganha", qtd.toFixed(2), "salários mínimos");
