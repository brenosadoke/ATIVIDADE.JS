// att6.js
let valor = 200;

let reajustado = valor * 1.05;
console.log("Valor com 5% de reajuste:", reajustado.toFixed(2));
