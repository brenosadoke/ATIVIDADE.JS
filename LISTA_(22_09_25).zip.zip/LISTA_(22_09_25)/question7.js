// att7.js
let v1 = true;
let v2 = false;

if (v1 && v2) {
  console.log("Ambos são VERDADEIRO");
} else if (!v1 && !v2) {
  console.log("Ambos são FALSO");
} else {
  console.log("São diferentes");
}
