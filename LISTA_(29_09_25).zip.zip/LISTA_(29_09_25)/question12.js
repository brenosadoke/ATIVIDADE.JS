let valor = parseFloat(prompt("Digite o valor do produto:"));

let opcao = parseInt(prompt(
  "Escolha a forma de pagamento:\n" +
  "1 - À Vista em Dinheiro ou Pix (15% de desconto)\n" +
  "2 - À Vista no cartão (10% de desconto)\n" +
  "3 - Parcelado em 2x no cartão (preço normal)\n" +
  "4 - Parcelado em 3x ou mais no cartão (10% de juros)"
));

let valorFinal;

switch(opcao) {
  case 1:
    valorFinal = valor * 0.85; 
    break;
  case 2:
    valorFinal = valor * 0.90; 
    break;
  case 3:
    valorFinal = valor; 
    break;
  case 4:
    valorFinal = valor * 1.10; 
    break;
  default:
    alert("Opção inválida!");
    valorFinal = null;
}

if (valorFinal !== null) {
  alert("O valor final a ser pago é: R$ " + valorFinal.toFixed(2));
  console.log("O valor final a ser pago é: R$ " + valorFinal.toFixed(2));
}
