let nome = prompt("Digite o nome da pessoa:");
let idade = parseInt(prompt("Digite a idade da pessoa:"));

let situacao = idade >= 18 ? "maior de idade" : "menor de idade";

alert(nome + " é " + situacao);
console.log(nome + " é " + situacao);