let anoNascimento = parseInt(prompt("Digite o ano de nascimento:"));

let mesNascimento = parseInt(prompt("Digite o mês de nascimento (1-12):"));
let diaNascimento = parseInt(prompt("Digite o dia de nascimento (1-30):"));

let anoAtual = parseInt(prompt("Digite o ano atual:"));
let mesAtual = parseInt(prompt("Digite o mês atual (1-12):"));
let diaAtual = parseInt(prompt("Digite o dia atual (1-30):"));

let anos = anoAtual - anoNascimento;
let meses = mesAtual - mesNascimento;
let dias = diaAtual - diaNascimento;


if (dias < 0) {
    dias += 30;
    meses -= 1;
}
if (meses < 0) {
    meses += 12;
    anos -= 1;
}

alert("Você já viveu " + anos + " anos, " + meses + " meses e " + dias + " dias.");
console.log("Você já viveu " + anos + " anos, " + meses + " meses e " + dias + " dias.");