let a = parseFloat(prompt("Digite o primeiro lado do triângulo:"));
let b = parseFloat(prompt("Digite o segundo lado do triângulo:"));
let c = parseFloat(prompt("Digite o terceiro lado do triângulo:"));

function isTrianguloValido(a, b, c) {
    return a + b > c && a + c > b && b + c > a;
}

if (!isTrianguloValido(a, b, c)) {
    alert("Os valores não formam um triângulo válido.");
    console.log("Os valores não formam um triângulo válido.");
} else {
    let tipo = "";
    if (a === b && b === c) {
        tipo = "Equilátero";
    } else if (a === b || a === c || b === c) {
        tipo = "Isósceles";
    } else {
        tipo = "Escaleno";
    }
    alert("Triângulo válido. Tipo: " + tipo);
    console.log("Triângulo válido. Tipo: " + tipo);
}
