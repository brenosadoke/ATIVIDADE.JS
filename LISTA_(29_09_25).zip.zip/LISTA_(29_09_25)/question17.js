let fahrenheit = parseFloat(prompt("Digite a temperatura em Fahrenheit:"));

let celsius = (5 * (fahrenheit - 32)) / 9;

alert(fahrenheit + "°F correspondem a " + celsius.toFixed(2) + "°C");
console.log(fahrenheit + "°F correspondem a " + celsius.toFixed(2) + "°C");
