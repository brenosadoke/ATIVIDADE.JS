let francisco = 1.50;
let sara = 1.10;

let crescimentoFrancisco = 0.02; 
let crescimentoSara = 0.03;      

let anos = 0;

while (sara <= francisco) {
    francisco += crescimentoFrancisco;
    sara += crescimentoSara;
    anos++;
}

alert("Sara ultrapassará Francisco em " + anos + " anos.");
console.log("Sara ultrapassará Francisco em " + anos + " anos.");
