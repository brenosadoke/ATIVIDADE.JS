let aleatorio = Math.floor(Math.random() * 101); 

alert("Número aleatório: " + aleatorio);
console.log("Número aleatório: " + aleatorio);
