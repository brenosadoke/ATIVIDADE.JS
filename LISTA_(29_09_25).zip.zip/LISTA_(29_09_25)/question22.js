let a = parseInt(prompt("Digite o valor de A:"));
let b = parseInt(prompt("Digite o valor de B:"));

let quociente = Math.floor(a / b); 
let resto = a % b;

alert("Quociente: " + quociente + "\nResto: " + resto);
console.log("Quociente: " + quociente + "\nResto: " + resto);
