
let a = parseInt(prompt("Digite o primeiro número:"));
let b = parseInt(prompt("Digite o segundo número:"));
let c = parseInt(prompt("Digite o terceiro número:"));


let numeros = [a, b, c];


numeros.sort(function(x, y) {
  return y - x;
});


console.log("Valores em ordem decrescente:", numeros.join(", "));
