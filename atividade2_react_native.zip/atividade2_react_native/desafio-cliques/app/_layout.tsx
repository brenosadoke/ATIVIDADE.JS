import React from 'react';
import DesafioDeCliques from './desafio';

export default function Layout() {
  return <DesafioDeCliques />;
}
