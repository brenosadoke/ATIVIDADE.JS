import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

// Variáveis globais (conforme enunciado — sem useEffect)
let intervalId: ReturnType<typeof setInterval> | null = null;
let running = false;
let currentClicks = 0;

const DesafioDeCliques: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<number>(10);
  const [clicks, setClicks] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [record, setRecord] = useState<number>(0);

  function iniciarOuParar() {
    if (isRunning) {
      // Parar o desafio imediatamente
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
      running = false;
      setIsRunning(false);
      return;
    }

    // Iniciar novo desafio
    currentClicks = 0;
    setClicks(0);
    setTimeLeft(10);
    setIsRunning(true);
    running = true;

    intervalId = setInterval(() => {
      setTimeLeft(prev => {
        const novo = prev - 1;

        if (novo <= 0) {
          // Tempo acabou: encerrar
          if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
          }
          running = false;
          setIsRunning(false);

          // Atualiza recorde usando currentClicks (variável global)
          setRecord(prevRecord => (currentClicks > prevRecord ? currentClicks : prevRecord));

          return 0;
        }

        return novo;
      });
    }, 1000);
  }

  function handleClick() {
    if (!isRunning || timeLeft <= 0) return;
    currentClicks += 1;
    setClicks(currentClicks);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Desafio de Cliques</Text>

      <View style={styles.card}>
        <Text style={styles.label}>Tempo restante</Text>
        <Text style={styles.time}>{timeLeft}s</Text>

        <TouchableOpacity
          style={[styles.clickButton, (!isRunning || timeLeft <= 0) && styles.clickButtonDisabled]}
          activeOpacity={0.7}
          onPress={handleClick}
        >
          <Text style={styles.clickButtonText}>CLIQUE!</Text>
        </TouchableOpacity>

        <Text style={styles.info}>Cliques: {clicks}</Text>
        <Text style={styles.info}>Recorde: {record}</Text>

        <TouchableOpacity
          style={styles.startButton}
          onPress={iniciarOuParar}
        >
          <Text style={styles.startButtonText}>{isRunning ? 'PARAR DESAFIO' : 'INICIAR DESAFIO'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default DesafioDeCliques;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    marginBottom: 16,
  },
  card: {
    width: '100%',
    padding: 20,
    borderRadius: 12,
    backgroundColor: 'white',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 4,
  },
  label: {
    fontSize: 16,
    marginBottom: 6,
  },
  time: {
    fontSize: 48,
    fontWeight: '800',
    marginBottom: 12,
  },
  clickButton: {
    width: '80%',
    paddingVertical: 14,
    borderRadius: 10,
    backgroundColor: '#0066FF',
    alignItems: 'center',
    marginVertical: 10,
  },
  clickButtonDisabled: {
    backgroundColor: '#BFCFEA',
  },
  clickButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
  },
  info: {
    marginTop: 8,
    fontSize: 16,
  },
  startButton: {
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 8,
    backgroundColor: '#1C7C54',
  },
  startButtonText: {
    color: 'white',
    fontWeight: '700',
  },
});
