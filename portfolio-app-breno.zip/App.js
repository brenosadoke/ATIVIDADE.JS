import React from 'react';
import { SafeAreaView, StatusBar, ScrollView } from 'react-native';
import { styles } from './styles/globalStyles';
import Header from './components/Header';
import Projects from './components/Projects';
import Footer from './components/Footer';
import { registerRootComponent } from 'expo';

export default function App() {
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <ScrollView contentContainerStyle={styles.container}>
        <Header />
        <Projects />
        <Footer />
      </ScrollView>
    </SafeAreaView>
  );
}

registerRootComponent(App);