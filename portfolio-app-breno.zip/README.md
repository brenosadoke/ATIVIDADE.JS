# PortfolioApp (Expo)

## Como usar
1. Instale expo-cli (opcional): `npm install -g expo-cli`
2. `npm install`
3. `npm start`
