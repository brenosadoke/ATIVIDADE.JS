import React from 'react';
import { View, Text } from 'react-native';
import { styles } from '../styles/globalStyles';

export default function Footer() {
  return (
    <View style={styles.footer}>
      <Text style={styles.contactText}>Facebook: @teste</Text>
      <Text style={styles.contactText}>WhatsApp: (00) 00000-0000</Text>
      <Text style={styles.contactText}>Email: email@teste.com</Text>
      <Text style={styles.contactText}>LinkedIn: linkedin.com/in/teste</Text>
    </View>
  );
}