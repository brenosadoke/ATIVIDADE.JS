import React from 'react';
import { View, Text, Image } from 'react-native';
import { styles } from '../styles/globalStyles';

export default function Header() {
  return (
    <View>
      <View style={styles.headerWrap}>
        <Text style={styles.nameText}>Breno Sadoque Alves Dias</Text>
        <Image source={require('../assets/minhaFoto.jpg')} style={styles.avatar} />
      </View>

      <Text style={styles.title}>PORTFÓLIO</Text>
      <Image source={require('../assets/minhaFoto.jpg')} style={styles.banner} />
    </View>
  );
}