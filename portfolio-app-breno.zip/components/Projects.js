import React from 'react';
import { View, Text } from 'react-native';
import { styles } from '../styles/globalStyles';

const projetos = [
  { id: 'p1', titulo: 'Projeto 1', descricao: 'Descrição exemplo' },
  { id: 'p2', titulo: 'Projeto 2', descricao: 'Descrição exemplo' },
  { id: 'p3', titulo: 'Projeto 3', descricao: 'Descrição exemplo' }
];

export default function Projects() {
  return (
    <View>
      <Text style={styles.sectionTitle}>TÍTULO</Text>
      {projetos.map(p => (
        <View key={p.id} style={styles.card}>
          <Text style={styles.cardTitle}>{p.titulo}</Text>
          <Text style={styles.cardText}>{p.descricao}</Text>
        </View>
      ))}
    </View>
  );
}