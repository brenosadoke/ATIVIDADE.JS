import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  container: { padding: 20, paddingBottom: 40 },

  headerWrap: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  nameText: { fontSize: 20, fontWeight: '700' },
  avatar: { width: 80, height: 80, borderRadius: 40 },

  title: { fontSize: 22, fontWeight: '700', marginTop: 10 },
  banner: { width: '100%', height: 200, borderRadius: 10, marginTop: 10 },

  sectionTitle: { fontSize: 18, fontWeight: '600', marginTop: 20 },
  card: { padding: 14, marginTop: 12, backgroundColor: '#f2f2f2', borderRadius: 8 },
  cardTitle: { fontSize: 16, fontWeight: '600' },
  cardText: { marginTop: 6, fontSize: 14, color: '#333' },

  footer: { marginTop: 24, borderTopWidth: 1, borderColor: '#ddd', paddingTop: 14 },
  contactText: { fontSize: 15, marginTop: 6 }
});